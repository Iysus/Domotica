﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Configuration;
using System.Drawing;

namespace Domotica.restricted
{
    public partial class WebDashboard : System.Web.UI.Page
    {
        static OleDbConnection conn = new OleDbConnection();

        private void button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string id = btn.ID;
            string WebsiteURL = "";

            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["Webdashboardconn"].ToString();

            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT * FROM Websites WHERE ID = 90;";
            OleDbParameter paran = new OleDbParameter();
            paran.Value = id;
            cmd.Parameters.Add(paran);

            try
            {
                conn.Open();
                OleDbDataReader reader = cmd.ExecuteReader();
                WebsiteURL = reader["WebsiteURL"].ToString();
            }
            finally
            {
                conn.Close();
                if(!WebsiteURL.StartsWith("http://"))
                {
                    WebsiteURL = "http://" + WebsiteURL;
                }
                System.Diagnostics.Process.Start(WebsiteURL);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["Webdashboardconn"].ToString();
                OleDbCommand cmd = new OleDbCommand();
                try
                {
                    conn.Open();
                    cmd.CommandText = $"SELECT * FROM Websites WHERE User = '{User.Identity.Name}' ORDER BY Naam";
                    cmd.Connection = conn;
                    OleDbDataReader reader = cmd.ExecuteReader();
                    foreach(object o in reader)
                    {
                        Button b = new Button();
                        b.ID = reader["ID"].ToString();
                        b.Text = reader["Naam"].ToString();
                        b.Width = b.Height = 200;
                        b.BackColor = Color.FromName(reader["Color"].ToString());
                        b.Font.Size = 20;
                        b.Click += new EventHandler(button_Click);
                        pnlButtons.Controls.Add(b);
                    }
                }
                finally
                {
                    conn.Close();
                }
      
            //}
        }
    }
}