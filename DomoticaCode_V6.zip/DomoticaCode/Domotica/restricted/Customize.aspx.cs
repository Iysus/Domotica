﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Configuration;

namespace Domotica.restricted
{
    public partial class Customize : System.Web.UI.Page
    {
        static OleDbConnection conn = new OleDbConnection();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblUsername.Text = User.Identity.Name;
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["Webdashboardconn"].ToString();
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {

            if (txtWebsiteUrl.Text != "")
            {
                OleDbCommand cmd = new OleDbCommand();
                cmd.CommandText = "INSERT INTO Websites ( [User], WebsiteURL, Naam, Color )"
                    + "SELECT ? AS Expr1, ? AS Expr2, ? AS Expr3, ? AS Expr4;";
                cmd.Parameters.Add("@User", OleDbType.VarChar, 128).Value = User.Identity.Name;
                cmd.Parameters.Add("@WebsiteURL", OleDbType.VarChar, 128).Value = txtWebsiteUrl.Text;
                cmd.Parameters.Add("@Naam", OleDbType.VarChar, 128).Value = txtNaam.Text;
                cmd.Parameters.Add("@Color", OleDbType.VarChar, 128).Value = ddlColor.Text;
                try
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.ExecuteNonQuery();
                }
                finally
                {
                    conn.Close();
                }

                GridView1.DataBind();
            }
        }
    }
}